package com.capgemini.lesson14;


public class Calculator
{
    public static int squared(int x)
    {
        return x * x;
    }
	public static int divide(int divisor)
	{
		int result=0;
		result=100/divisor;
		return result;
	}
}